# Comp 3450 Immutable Map Class

## Author

**Caleb St Clair**

## Description

This is my implementation of a Immutable Map class which allows the creation of a map object that cannot be changed. This map is implemented as a binary search tree.

## External Resources

- Class notes

## Strengths

The class is able to use recursion to add new nodes to the map which greatly reduces the amount of code. The binary search tree greatly increases its speed

## Weaknesses

I don't think this class has any potential weaknesses that I can think of.